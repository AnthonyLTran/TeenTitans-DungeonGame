package MiniTextGame;

public class Item {

        private int itemID;
        private String itemName;
        private String itemDescription;
        private String itemEffect;
        private int itemRoomID;


        public Item() {

        }

        public String getItemName() {
                return itemName;
        }

        public int getItemID() {
                return itemID;
        }

        public void setItemID(int itemID) {
                this.itemID = itemID;
        }

        public void setItemName(String itemName) {
                this.itemName = itemName;
        }

        public String getItemDescription() {
                return itemDescription;
        }

        public void setItemDescription(String itemDescription) {
                this.itemDescription = itemDescription;
        }

        public String getItemEffect() {
                return itemEffect;
        }

        public void setItemEffect(String itemEffect) {
                this.itemEffect = itemEffect;
        }

        public int getItemRoomID() {
                return itemRoomID;
        }

        public void setItemRoomID(int roomID) {
                this.itemRoomID = roomID;
        }

        @Override
        public String toString() {
                return "Item{" +
                        "itemID=" + itemID +
                        ", itemName='" + itemName + '\'' +
                        ", itemDescription='" + itemDescription + '\'' +
                        ", itemEffect='" + itemEffect + '\'' +
                        ", itemRoomID=" + itemRoomID +
                        '}';
        }
}

