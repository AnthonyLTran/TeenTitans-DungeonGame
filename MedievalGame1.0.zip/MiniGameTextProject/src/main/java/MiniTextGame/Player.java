package MiniTextGame;

import java.util.ArrayList;

public class Player {

    public ArrayList<Item> inventory;
    private int currentRoomID;

    public Player() {
        inventory = new ArrayList<>();
    }


    public void pickUpItem (Item item) {
        inventory.add(item);
    }

    public ArrayList<Item> getInventory() {
        return inventory;
    }

    public void setInventory(ArrayList<Item> inventory) {
        this.inventory = inventory;
    }


    public int getCurrentRoomID() {
        return currentRoomID;
    }

    public void setCurrentRoomID(int currentRoomID) {
        this.currentRoomID = currentRoomID;
    }

    @Override
    public String toString() {
        return "Player{" +
                "inventory=" + inventory +
                ", currentRoomID=" + currentRoomID +
                '}';
    }
}


