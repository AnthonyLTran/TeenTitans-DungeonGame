package MiniTextGame;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

/**
 * Anthony Morse
 * Rahaf Barakat ITEC3960
 * MiniText Adventure Game Part 2
 * October 5 2021
 */

public class Main {

    public static Player player;
    public static Room currentRoom;
    public static boolean gameFlag = true;
    public static Scanner input = new Scanner(System.in);
    public static String choice;
    public static int nextRoomID;
    public static int commandType;
    //command type 0 is invalid, command type 1 is movement, command type 2 is non movement

    public static void main(String[] args) throws IOException {
        ArrayList<Room> rooms = RoomInput.getRooms();
        ArrayList<Puzzle> puzzles = PuzzleInput.getPuzzles();
        for (Puzzle puzzle : puzzles) {
            Room room = rooms.get(puzzle.getPuzzleRoomID() - 1);
            room.setPuzzle(puzzle);
        }

        player = new Player();

        System.out.println("Welcome to Castle Climb!");
        currentRoom = rooms.get(0);
        displayCurrentRoom();
        displayPuzzle();

        //main game loop

        do {

            System.out.println("Which way do you want to go? [n,s,e,w, explore, inventory, pickup, drop, or quit]");
            System.out.print(">");
            choice = input.nextLine();

            if (!gameFlag) {
                break;
            }

            processChoice();

            if (commandType == 1) {
                if (nextRoomID == 0) {
                    System.out.println("You can't go that way.");
                } else {
                    //updating the current room
                    currentRoom = rooms.get(nextRoomID - 1);
                    displayCurrentRoom();
                    displayPuzzle();
                }
            } else if (commandType == 2) {
                continue;
            } else {
                System.out.println("Invalid command");
            }
        } while (gameFlag);
        System.out.println("Game was ended. Thanks for playing!");
    }

    public static void displayCurrentRoom() {
        //keeping track of visited rooms
        if (currentRoom.getWasVisited()) {
            System.out.println("You've been here before.");
        } else {
            currentRoom.setWasVisited(true);
        }
        System.out.println(currentRoom.getRoomName());
        for (int i = 0; i < currentRoom.getDescriptions().size(); i++) {
            System.out.println(currentRoom.getDescriptions().get(i));
        }
    }

    public static void displayPuzzle() {
        if (!currentRoom.getPuzzle().wasSolved()) {
            System.out.println("There is a puzzle in this room");
            System.out.println(currentRoom.getPuzzle().getPuzzleName());
            System.out.println(currentRoom.getPuzzle().getPuzzleDescription());
            int attempts = currentRoom.getPuzzle().getAttempts();

            do {
                System.out.print(">");
                String answer = input.nextLine();
                answer = answer.toLowerCase();
                if (answer.compareTo(currentRoom.getPuzzle().getPuzzleAnswer()) == 0) {
                    System.out.println("Correct!");
                    currentRoom.getPuzzle().setWasSolved(true);
                    return;
                }
                attempts--;
                if(attempts > 0) {
                    System.out.println("Incorrect. You have " + attempts + " attempts remaining.");
                } else {
                    break;
                }
            } while (attempts > 0);
                System.out.println("You are out of attempts.");
            }
        }

    public static void displayItem() {

        if (currentRoom.getRoomInventory().size() > 0) {
            System.out.println("In the room you see ");
            ArrayList<Item> roomInventory = currentRoom.getRoomInventory();
            for (Item item : roomInventory) {
                System.out.println(item.getItemName());
            }
        } else {
            System.out.println("No items in this room.");
        }
    }

    public static void checkInventory() {
        if (player.getInventory().size() > 0) {
            System.out.println("You are holding:  ");
            ArrayList<Item> inventory = player.getInventory();
            for (Item item : inventory) {
                System.out.println(item.getItemName());
            }
        } else {
            System.out.println("Inventory is empty.");
        }
    }

    public static void processChoice() {
        //normalizing input
        choice = choice.toLowerCase();
        String[] choiceWords = choice.split(" ");
        String itemName = "";
        if (choiceWords.length > 1) {
            itemName = choiceWords[1];
            for (int i = 2; i < choiceWords.length; i++) {
                itemName += " " + choiceWords[i];
            }
        }
        if(choiceWords.length == 1) {
            Map<String, Integer> nav = currentRoom.getNavTable();
            if (choice.compareTo("explore") == 0) {
                displayItem();
                commandType = 2;
            } else if (choice.compareTo("inventory") == 0) {
                checkInventory();
                commandType = 2;
            } else if (choice.compareTo("north") == 0 || choice.compareTo("n") == 0) {
                nextRoomID = nav.get("north");
                commandType = 1;
            } else if (choice.compareTo("east") == 0 || choice.compareTo("e") == 0) {
                nextRoomID = nav.get("east");
                commandType = 1;
            } else if (choice.compareTo("west") == 0 || choice.compareTo("w") == 0) {
                nextRoomID = nav.get("west");
                commandType = 1;
            } else if (choice.compareTo("south") == 0 || choice.compareTo("s") == 0) {
                nextRoomID = nav.get("south");
                commandType = 1;
            } else if (choice.compareTo("quit") == 0 || choice.compareTo("q") == 0) {
                gameFlag = false;
                commandType = 2;
            } else {
                commandType = 0;
            }
        }
        else if (choiceWords.length > 1) {
            if (choiceWords[0].compareTo("pickup") == 0) {
                ArrayList<Item> roomInventory = currentRoom.getRoomInventory();
                for (int i = 0; i < roomInventory.size(); i++) {
                    if (itemName.compareTo(roomInventory.get(i).getItemName()) == 0) {
                        player.getInventory().add(roomInventory.get(i));
                        roomInventory.remove(i);
                        System.out.println("You have picked up the " + itemName + ".");
                        commandType = 2;
                        return;
                    }
                }
                System.out.println("Can't find that item.");
                commandType = 2;
            }
            else if (choiceWords[0].compareTo("drop") == 0) {
                ArrayList<Item> inventory = player.getInventory();
                for (int i = 0; i < inventory.size(); i++) {
                    if (itemName.compareTo(player.getInventory().get(i).getItemName()) == 0) {
                        currentRoom.getRoomInventory().add(inventory.get(i));
                        inventory.remove(i);
                        System.out.println("Item has been dropped and added to " + currentRoom.getRoomName());
                        commandType = 2;
                        return;
                    }
                }
                System.out.println("You don't have that item.");
                commandType = 2;
            }
            else if (choiceWords[0].compareTo("inspect") == 0) {
                ArrayList<Item> inventory = player.getInventory();
                for (int i = 0; i < inventory.size(); i++) {
                    if (itemName.compareTo(player.getInventory().get(i).getItemName()) == 0) {
                        System.out.println(inventory.get(i).getItemDescription());
                        System.out.println(inventory.get(i).getItemEffect());
                        commandType = 2;
                        return;
                    }
                }
                System.out.println("You don't have that item.");
                commandType = 2;
            }
        }
    }
}

