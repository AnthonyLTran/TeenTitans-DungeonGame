package MiniTextGame;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ItemInput {

    private static ArrayList<Item> items = new ArrayList<>();
    public static ArrayList<Item> getItems() {

        try {

            List<String> lines = FileUtils.readLines(new File("Items.txt"),"UTF-8");

            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                Item item = new Item();
                String[] itemData = line.split(",");
                int j = 0;
                item.setItemID(Integer.parseInt(itemData[j]));
                j++;
                item.setItemName(itemData[j]);
                j++;
                item.setItemDescription(itemData[j]);
                j++;
                item.setItemEffect(itemData[j]);
                j++;
                item.setItemRoomID(Integer.parseInt(itemData[j]));
                items.add(item);
            }
        } catch (Exception e) {
            System.out.println("Item not found.");
            e.printStackTrace();
        }
        return items;
    }
}
