package MiniTextGame;

import java.util.ArrayList;
import java.util.HashMap;

public class Room {

    private int roomID;
    private String roomName;
    private ArrayList<String> descriptions;
    private boolean wasVisited;
    private HashMap<String,Integer> navTable;
    private Puzzle puzzle;
    private ArrayList<Item> roomInventory;
    private Item item;

    public Room() {
        descriptions = new ArrayList<>();
        navTable = new HashMap<>();
        roomInventory = new ArrayList<>();
    }

    public Room(int roomID, String roomName, boolean wasVisited) {
        this.roomID = roomID;
        this.roomName = roomName;
        this.wasVisited = wasVisited;
    }

    public int getRoomID() {
        return roomID;
    }

    public void setRoomID(int roomId) {
        this.roomID = roomId;
    }

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public boolean getWasVisited() {
        return wasVisited;
    }

    public void setWasVisited(boolean wasVisited) {
        this.wasVisited = wasVisited;
    }

    public ArrayList<String> getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(ArrayList<String> descriptions) {
        this.descriptions = descriptions;
    }

    public HashMap<String, Integer> getNavTable() {
        return navTable;
    }

    public void setNavTable(HashMap<String, Integer> navTable) {
        this.navTable = navTable;
    }

    public Puzzle getPuzzle() {
        return puzzle;
    }

    public void setPuzzle(Puzzle puzzle) {
        this.puzzle = puzzle;
    }

    public Item getItem() {
        return this.item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public ArrayList<Item> getRoomInventory() {
        return roomInventory;
    }


    @Override
    public String toString() {
        return "Room{" +
                "roomId=" + roomID +
                ", roomName='" + roomName + '\'' +
                ", descriptions=" + descriptions +
                ", wasVisited=" + wasVisited +
                ", navTable=" + navTable +
                ", puzzle=" + puzzle +
                ", item=" + item +
                '}';
    }
}





