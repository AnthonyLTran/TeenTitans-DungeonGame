package MiniTextGame;

import java.util.ArrayList;

public class Inventory {

    private ArrayList<Item> inventory;


    public Inventory() {
        this.inventory = new ArrayList<>();
    }

    public ArrayList<Item> getInventory() {
        return inventory;
    }

    public void setInventory(ArrayList<Item> inventory) {
        this.inventory = inventory;
    }

    public void pickUp(Item item) {
        inventory.add(item);
    }

    @Override
    public String toString() {
        return "Inventory{" +
                "inventory=" + inventory +
                '}';
    }

    public void add(Item item) {
        inventory.add(item);
    }
}
